public enum StatType
{
    Float,
    Bool,
    Int
}
