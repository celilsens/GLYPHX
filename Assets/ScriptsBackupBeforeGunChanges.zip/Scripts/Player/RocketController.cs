using UnityEngine;

public class RocketController : MonoBehaviour
{
    private float _power => StatManager.Instance.GetFloatStat(Consts.Upgrades.ROCKET_POWER);
    private float _radius => StatManager.Instance.GetFloatStat(Consts.Upgrades.ROCKET_RADIUS);
    [SerializeField] private GameObject explosionEffect;

    private bool hasExploded = false;

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (hasExploded) return;

        if (other.CompareTag("Enemy"))
        {
            Explode();
        }

        if (other.CompareTag("Boundary"))
        {
            Destroy(gameObject);
        }
    }

    private void Explode()
    {
        hasExploded = true;

        if (explosionEffect != null)
            Instantiate(explosionEffect, transform.position, Quaternion.identity);

        Collider2D[] hits = Physics2D.OverlapCircleAll(transform.position, _radius);

        foreach (var hit in hits)
        {
            if (hit.TryGetComponent<IDamageable>(out var damageable))
            {
                damageable.TakeDamage(_power);
            }
        }

        Destroy(gameObject);
    }
}
