using UnityEngine;

public class BulletController : MonoBehaviour
{
    [SerializeField] private float _speed = 10f;

    private Rigidbody2D _rb;

    private void Awake()
    {
        _rb = GetComponent<Rigidbody2D>();
    }

    private void Start()
    {
        _rb.linearVelocity = transform.up * _speed;
    }

    private void FixedUpdate()
    {
        if (GameManager.Instance != null && !GameManager.Instance.IsGameActive)
            _rb.linearVelocity = Vector2.zero;
        else
            _rb.linearVelocity = transform.up * _speed;
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.CompareTag("Enemy"))
        {
            float damage = StatManager.Instance.GetFloatStat(Consts.Upgrades.BASE_DAMAGE) *
                           StatManager.Instance.GetFloatStat(Consts.Upgrades.DAMAGE_MULTIPLIER);

            float critChance = StatManager.Instance.GetFloatStat(Consts.Upgrades.CRITICAL_HIT_RATE);
            if (Random.value <= critChance)
            {
                float critMultiplier = StatManager.Instance.GetFloatStat(Consts.Upgrades.CRITICAL_HIT_MULTIPLIER);
                damage *= critMultiplier;
            }

            if (collision.TryGetComponent<IDamageable>(out var damageable))
                damageable.TakeDamage(damage);

            Destroy(gameObject);
        }
        else if (collision.CompareTag("Boundary"))
        {
            Destroy(gameObject);
        }
    }
}
